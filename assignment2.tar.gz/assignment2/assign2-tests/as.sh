for num in {0..24}
do
    clang -emit-llvm -c -g `printf "test%02d.c" $num` 
    llvm-dis `printf "test%02d.bc" $num` 
done

