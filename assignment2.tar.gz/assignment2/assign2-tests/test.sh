for num in {0..24}
do
    echo `printf "test%02d.bc" $num` 
    ../build/llvmassignment `printf "test%02d.bc" $num` 
done

